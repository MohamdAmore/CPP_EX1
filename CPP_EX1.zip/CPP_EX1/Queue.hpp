// Email: mhmd2.ma71@gmail.com
#pragma once

namespace graph {

    class Queue {
    private:
        int* data;
        int front;
        int rear;
        int size;
        int capacity;

    public:
        Queue(int capacity);
        ~Queue();

        void enqueue(int value);
        int dequeue();
        bool isEmpty() const;
        bool isFull() const;
    };

}
