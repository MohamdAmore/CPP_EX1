// Email: mhmd2.ma71@gmail.com
#include "Algorithms.hpp"
#include "Queue.hpp"
#include "PriorityQueue.hpp"
#include "UnionFind.hpp"
#include <limits>
#include <stdexcept>

namespace graph {

    Graph Algorithms::bfs(const Graph& g, int startVertex) {
        int n = g.getVertexCount(); // We'll add this function to Graph shortly

        if (startVertex < 0 || startVertex >= n) {
            throw std::out_of_range("Invalid start vertex");
        }

        Graph tree(n); // Tree to be returned
        bool* visited = new bool[n];
        for (int i = 0; i < n; ++i) visited[i] = false;

        Queue q(n);
        visited[startVertex] = true;
        q.enqueue(startVertex);

        while (!q.isEmpty()) {
            int u = q.dequeue();

            const Neighbor* neighbor = g.getAdjList(u);
            while (neighbor) {
                int v = neighbor->vertex;
                if (!visited[v]) {
                    visited[v] = true;
                    tree.addEdge(u, v, neighbor->weight); // Add edge to BFS tree
                    q.enqueue(v);
                }
                neighbor = neighbor->next;
            }
        }

        delete[] visited;
        return tree;
    }
    static void dfs_visit(const Graph& g, int u, bool* visited, Graph& tree);

    Graph Algorithms::dfs(const Graph& g, int startVertex) {
        int n = g.getVertexCount();
        if (startVertex < 0 || startVertex >= n) {
            throw std::out_of_range("Invalid start vertex");
        }

        Graph tree(n);
        bool* visited = new bool[n];
        for (int i = 0; i < n; ++i) visited[i] = false;

        dfs_visit(g, startVertex, visited, tree);

        // If it's a forest (not all nodes reachable), explore the rest
        for (int i = 0; i < n; ++i) {
            if (!visited[i]) {
                dfs_visit(g, i, visited, tree);
            }
        }

        delete[] visited;
        return tree;
    }

    static void dfs_visit(const Graph& g, int u, bool* visited, Graph& tree) {
        visited[u] = true;

        const Neighbor* neighbor = g.getAdjList(u);
        while (neighbor) {
            int v = neighbor->vertex;
            if (!visited[v]) {
                tree.addEdge(u, v, neighbor->weight); // Tree edge
                dfs_visit(g, v, visited, tree);
            }
            neighbor = neighbor->next;
        }
    }
    
    Graph Algorithms::dijkstra(const Graph& g, int startVertex) {
        int n = g.getVertexCount();
        if (startVertex < 0 || startVertex >= n) {
            throw std::out_of_range("Invalid start vertex");
        }

        const int INF = std::numeric_limits<int>::max();

        int* dist = new int[n];
        int* parent = new int[n];
        bool* visited = new bool[n];

        for (int i = 0; i < n; ++i) {
            dist[i] = INF;
            parent[i] = -1;
            visited[i] = false;
        }

        dist[startVertex] = 0;

        PriorityQueue pq(n);
        pq.insert(startVertex, 0);

        while (!pq.isEmpty()) {
            int u = pq.extractMin();
            visited[u] = true;

            const Neighbor* neighbor = g.getAdjList(u);
            while (neighbor) {
                int v = neighbor->vertex;
                int weight = neighbor->weight;

                if (!visited[v] && dist[u] + weight < dist[v]) {
                    dist[v] = dist[u] + weight;
                    parent[v] = u;
                    pq.insert(v, dist[v]); // insert or update
                }

                neighbor = neighbor->next;
            }
        }

        // Build the shortest path tree
        Graph tree(n);
        for (int v = 0; v < n; ++v) {
            if (parent[v] != -1) {
                tree.addEdge(v, parent[v], dist[v] - dist[parent[v]]);
            }
        }

        delete[] dist;
        delete[] parent;
        delete[] visited;

        return tree;
    }

    Graph Algorithms::prim(const Graph& g, int startVertex) {
        int n = g.getVertexCount();
        if (startVertex < 0 || startVertex >= n) {
            throw std::out_of_range("Invalid start vertex");
        }

        const int INF = std::numeric_limits<int>::max();

        int* key = new int[n];
        int* parent = new int[n];
        bool* inMST = new bool[n];

        for (int i = 0; i < n; ++i) {
            key[i] = INF;
            parent[i] = -1;
            inMST[i] = false;
        }

        key[startVertex] = 0;
        PriorityQueue pq(n);
        pq.insert(startVertex, 0);

        while (!pq.isEmpty()) {
            int u = pq.extractMin();
            inMST[u] = true;

            const Neighbor* neighbor = g.getAdjList(u);
            while (neighbor) {
                int v = neighbor->vertex;
                int weight = neighbor->weight;

                if (!inMST[v] && weight < key[v]) {
                    key[v] = weight;
                    parent[v] = u;
                    pq.insert(v, key[v]);
                }

                neighbor = neighbor->next;
            }
        }

        Graph mst(n);
        for (int v = 0; v < n; ++v) {
            if (parent[v] != -1) {
                mst.addEdge(v, parent[v], key[v]);
            }
        }

        delete[] key;
        delete[] parent;
        delete[] inMST;

        return mst;
    }
    struct Edge {
        int u, v, weight;
    };

    // Simple bubble sort without STL
    void sortEdges(Edge* edges, int count) {
        for (int i = 0; i < count - 1; ++i) {
            for (int j = 0; j < count - i - 1; ++j) {
                if (edges[j].weight > edges[j + 1].weight) {
                    Edge temp = edges[j];
                    edges[j] = edges[j + 1];
                    edges[j + 1] = temp;
                }
            }
        }
    }

    Graph Algorithms::kruskal(const Graph& g) {
        int n = g.getVertexCount();
        Graph mst(n);

        // Step 1: Collect all edges
        Edge* edges = new Edge[n * n]; // worst-case upper bound
        int edgeCount = 0;

        for (int u = 0; u < n; ++u) {
            const Neighbor* neighbor = g.getAdjList(u);
            while (neighbor) {
                int v = neighbor->vertex;
                int w = neighbor->weight;
                if (u < v) { // avoid duplicates
                    edges[edgeCount++] = {u, v, w};
                }
                neighbor = neighbor->next;
            }
        }

        // Step 2: Sort edges by weight
        sortEdges(edges, edgeCount);

        // Step 3: Union-Find to build MST
        UnionFind uf(n);
        for (int i = 0; i < edgeCount; ++i) {
            int u = edges[i].u;
            int v = edges[i].v;
            int w = edges[i].weight;

            if (uf.find(u) != uf.find(v)) {
                mst.addEdge(u, v, w);
                uf.unite(u, v);
            }
        }

        delete[] edges;
        return mst;
    }

}
