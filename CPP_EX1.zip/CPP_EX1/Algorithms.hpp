// Email: mhmd2.ma71@gmail.com
#pragma once

#include "graph.hpp"

namespace graph {

    class Algorithms {
    public:
        static Graph bfs(const Graph& g, int startVertex);
        static Graph dfs(const Graph& g, int startVertex);
        static Graph dijkstra(const Graph& g, int startVertex);
        static Graph prim(const Graph& g, int startVertex);
        static Graph kruskal(const Graph& g);
    };

}
