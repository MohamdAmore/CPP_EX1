// Email: mhmd2.ma71@gmail.com
#include "graph.hpp"
#include "Algorithms.hpp"
#include <iostream>

using namespace graph;

int main() {
    try {
        // Create a graph with 6 vertices
        Graph g(6);

        // Add some edges
        g.addEdge(0, 1, 4);
        g.addEdge(0, 2, 2);
        g.addEdge(1, 2, 1);
        g.addEdge(1, 3, 5);
        g.addEdge(2, 3, 8);
        g.addEdge(3, 4, 3);
        g.addEdge(4, 5, 7);

        std::cout << "Original Graph:" << std::endl;
        g.print_graph();

        std::cout << "\nGraph after removing edge (1, 2):" << std::endl;
        g.removeEdge(1, 2);
        g.print_graph();

        // Run BFS
        Graph bfsTree = Algorithms::bfs(g, 0);
        std::cout << "\nBFS Tree from vertex 0:" << std::endl;
        bfsTree.print_graph();

        // Run DFS
        Graph dfsTree = Algorithms::dfs(g, 0);
        std::cout << "\nDFS Tree from vertex 0:" << std::endl;
        dfsTree.print_graph();

        // Run Dijkstra
        Graph dijkstraTree = Algorithms::dijkstra(g, 0);
        std::cout << "\nDijkstra Shortest Paths Tree from vertex 0:" << std::endl;
        dijkstraTree.print_graph();

        // Run Prim
        Graph primTree = Algorithms::prim(g, 0);
        std::cout << "\nPrim MST from vertex 0:" << std::endl;
        primTree.print_graph();

        // Run Kruskal
        Graph kruskalTree = Algorithms::kruskal(g);
        std::cout << "\nKruskal MST:" << std::endl;
        kruskalTree.print_graph();
        
    } catch (const std::exception& e) {
        std::cerr << "Exception: " << e.what() << std::endl;
    }

    return 0;
}
