// Email: mhmd2.ma71@gmail.com
#pragma once

namespace graph {

    class PriorityQueue {
    private:
        struct Node {
            int vertex;
            int distance;
        };

        Node* data;
        int size;
        int capacity;

        void swap(int i, int j);
        void heapifyUp(int index);
        void heapifyDown(int index);

    public:
        PriorityQueue(int capacity);
        ~PriorityQueue();

        void insert(int vertex, int distance);
        int extractMin(); // returns vertex with min distance
        void decreaseKey(int vertex, int newDist);
        bool isEmpty() const;
        bool contains(int vertex) const;
        int getDistance(int vertex) const;
    };

}
