// Email: mhmd2.ma71@gmail.com
#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"
#include "graph.hpp"
#include "Algorithms.hpp"
#include "Queue.hpp"
#include "PriorityQueue.hpp"
#include "UnionFind.hpp"

using namespace graph;

TEST_CASE("Graph basic add/remove") {
    Graph g(5);
    g.addEdge(0, 1, 3);
    g.addEdge(1, 2, 4);
    CHECK(g.hasEdge(0, 1));
    CHECK(g.hasEdge(1, 2));
    g.removeEdge(1, 2);
    CHECK_FALSE(g.hasEdge(1, 2));
}

TEST_CASE("Graph edge cases") {
    Graph g(1);
    g.addEdge(0, 0, 5);
    CHECK(g.hasEdge(0, 0));
    g.removeEdge(0, 0);
    CHECK_FALSE(g.hasEdge(0, 0));

    Graph empty(0);
    CHECK(empty.getVertexCount() == 0);
}

TEST_CASE("Queue operations") {
    Queue q(3);
    CHECK(q.isEmpty());
    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    CHECK_THROWS(q.enqueue(40)); // overflow
    CHECK(q.dequeue() == 10);
    CHECK(q.dequeue() == 20);
    CHECK(q.dequeue() == 30);
    CHECK_THROWS(q.dequeue()); // underflow
}

TEST_CASE("PriorityQueue extract order") {
    PriorityQueue pq(4);
    pq.insert(3, 30);
    pq.insert(1, 10);
    pq.insert(2, 20);
    pq.insert(0, 5);

    CHECK(pq.extractMin() == 0);
    CHECK(pq.extractMin() == 1);
    CHECK(pq.extractMin() == 2);
    CHECK(pq.extractMin() == 3);
    CHECK(pq.isEmpty());
}

TEST_CASE("UnionFind behavior") {
    UnionFind uf(6);
    uf.unite(0, 1);
    uf.unite(1, 2);
    uf.unite(3, 4);
    CHECK(uf.find(0) == uf.find(2));
    CHECK(uf.find(3) == uf.find(4));
    CHECK(uf.find(0) != uf.find(3));
    uf.unite(2, 4);
    CHECK(uf.find(0) == uf.find(3));
}

TEST_CASE("BFS on connected graph") {
    Graph g(5);
    g.addEdge(0, 1, 1);
    g.addEdge(1, 2, 1);
    g.addEdge(2, 3, 1);
    g.addEdge(3, 4, 1);
    Graph bfsTree = Algorithms::bfs(g, 0);
    CHECK(bfsTree.hasEdge(0, 1));
    CHECK(bfsTree.hasEdge(1, 2));
    CHECK(bfsTree.hasEdge(2, 3));
    CHECK(bfsTree.hasEdge(3, 4));
}

TEST_CASE("DFS on connected graph") {
    Graph g(5);
    g.addEdge(0, 1, 1);
    g.addEdge(1, 2, 1);
    g.addEdge(2, 3, 1);
    g.addEdge(3, 4, 1);
    Graph dfsTree = Algorithms::dfs(g, 0);
    CHECK(dfsTree.hasEdge(0, 1));
    CHECK(dfsTree.hasEdge(1, 2));
    CHECK(dfsTree.hasEdge(2, 3));
    CHECK(dfsTree.hasEdge(3, 4));
}

TEST_CASE("Dijkstra shortest paths") {
    Graph g(4);
    g.addEdge(0, 1, 1);
    g.addEdge(1, 2, 2);
    g.addEdge(2, 3, 3);
    Graph dijTree = Algorithms::dijkstra(g, 0);
    CHECK(dijTree.hasEdge(0, 1));
    CHECK(dijTree.hasEdge(1, 2));
    CHECK(dijTree.hasEdge(2, 3));
}

TEST_CASE("Prim's MST contains valid edges") {
    Graph g(4);
    g.addEdge(0, 1, 4);
    g.addEdge(1, 2, 3);
    g.addEdge(2, 3, 2);
    g.addEdge(0, 3, 1);

    Graph mst = Algorithms::prim(g, 0);
    CHECK(mst.hasEdge(0, 3));
    CHECK(mst.hasEdge(3, 2));
    CHECK(mst.hasEdge(2, 1));
}

TEST_CASE("Kruskal's MST correctness") {
    Graph g(4);
    g.addEdge(0, 1, 4);
    g.addEdge(1, 2, 3);
    g.addEdge(2, 3, 2);
    g.addEdge(0, 3, 1);

    Graph mst = Algorithms::kruskal(g);
    CHECK(mst.hasEdge(0, 3));
    CHECK(mst.hasEdge(3, 2));
    CHECK(mst.hasEdge(2, 1));
}

TEST_CASE("BFS on disconnected graph") {
    Graph g(6);
    g.addEdge(0, 1, 1);
    g.addEdge(2, 3, 1);
    Graph bfs = Algorithms::bfs(g, 0);
    CHECK(bfs.hasEdge(0, 1));
    CHECK_FALSE(bfs.hasEdge(2, 3)); // not reachable from 0
}

