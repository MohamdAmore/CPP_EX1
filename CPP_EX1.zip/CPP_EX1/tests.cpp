// Email: mhmd2.ma71@gmail.com
#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"
#include "graph.hpp"
#include "Algorithms.hpp"

using namespace graph;

TEST_CASE("Graph basic add/remove") {
    Graph g(5);
    g.addEdge(0, 1, 3);
    g.addEdge(1, 2, 4);
    CHECK(g.hasEdge(0, 1));
    CHECK(g.hasEdge(1, 2));
    g.removeEdge(1, 2);
    CHECK_FALSE(g.hasEdge(1, 2));
}

TEST_CASE("BFS produces tree") {
    Graph g(4);
    g.addEdge(0, 1, 1);
    g.addEdge(1, 2, 1);
    g.addEdge(2, 3, 1);
    Graph bfsTree = Algorithms::bfs(g, 0);
    CHECK(bfsTree.hasEdge(0, 1));
    CHECK(bfsTree.hasEdge(1, 2));
    CHECK(bfsTree.hasEdge(2, 3));
}

TEST_CASE("DFS produces tree") {
    Graph g(4);
    g.addEdge(0, 1, 1);
    g.addEdge(1, 2, 1);
    g.addEdge(2, 3, 1);
    Graph dfsTree = Algorithms::dfs(g, 0);
    CHECK(dfsTree.hasEdge(0, 1));
    CHECK(dfsTree.hasEdge(1, 2));
    CHECK(dfsTree.hasEdge(2, 3));
}

TEST_CASE("Dijkstra shortest paths") {
    Graph g(4);
    g.addEdge(0, 1, 1);
    g.addEdge(1, 2, 1);
    g.addEdge(2, 3, 1);
    Graph dijTree = Algorithms::dijkstra(g, 0);
    CHECK(dijTree.hasEdge(0, 1));
    CHECK(dijTree.hasEdge(1, 2));
    CHECK(dijTree.hasEdge(2, 3));
}

TEST_CASE("Prim's MST contains valid edges") {
    Graph g(4);
    g.addEdge(0, 1, 4);
    g.addEdge(1, 2, 3);
    g.addEdge(2, 3, 2);
    g.addEdge(0, 3, 1);

    Graph mst = Algorithms::prim(g, 0);
    // check some expected MST edges based on weights
    CHECK(mst.hasEdge(0, 3));
    CHECK(mst.hasEdge(3, 2));
    CHECK(mst.hasEdge(2, 1));
}

TEST_CASE("Kruskal's MST correctness") {
    Graph g(4);
    g.addEdge(0, 1, 4);
    g.addEdge(1, 2, 3);
    g.addEdge(2, 3, 2);
    g.addEdge(0, 3, 1);

    Graph mst = Algorithms::kruskal(g);
    CHECK(mst.hasEdge(0, 3));
    CHECK(mst.hasEdge(3, 2));
    CHECK(mst.hasEdge(2, 1));
}

