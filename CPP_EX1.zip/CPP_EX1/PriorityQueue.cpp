// Email: mhmd2.ma71@gmail.com
#include "PriorityQueue.hpp"
#include <stdexcept>

namespace graph {

    PriorityQueue::PriorityQueue(int cap) : capacity(cap), size(0) {
        data = new Node[capacity];
    }

    PriorityQueue::~PriorityQueue() {
        delete[] data;
    }

    bool PriorityQueue::isEmpty() const {
        return size == 0;
    }

    void PriorityQueue::swap(int i, int j) {
        Node temp = data[i];
        data[i] = data[j];
        data[j] = temp;
    }

    void PriorityQueue::heapifyUp(int index) {
        while (index > 0) {
            int parent = (index - 1) / 2;
            if (data[index].distance < data[parent].distance) {
                swap(index, parent);
                index = parent;
            } else {
                break;
            }
        }
    }

    void PriorityQueue::heapifyDown(int index) {
        while (2 * index + 1 < size) {
            int left = 2 * index + 1;
            int right = 2 * index + 2;
            int smallest = index;

            if (left < size && data[left].distance < data[smallest].distance) {
                smallest = left;
            }
            if (right < size && data[right].distance < data[smallest].distance) {
                smallest = right;
            }

            if (smallest != index) {
                swap(index, smallest);
                index = smallest;
            } else {
                break;
            }
        }
    }

    void PriorityQueue::insert(int vertex, int distance) {
        if (contains(vertex)) {
            decreaseKey(vertex, distance);
            return;
        }
        if (size >= capacity) {
            throw std::overflow_error("PriorityQueue overflow");
        }

        data[size].vertex = vertex;
        data[size].distance = distance;
        heapifyUp(size);
        size++;
    }

    int PriorityQueue::extractMin() {
        if (isEmpty()) {
            throw std::underflow_error("PriorityQueue is empty");
        }

        int minVertex = data[0].vertex;
        data[0] = data[size - 1];
        size--;
        heapifyDown(0);
        return minVertex;
    }

    void PriorityQueue::decreaseKey(int vertex, int newDist) {
        for (int i = 0; i < size; ++i) {
            if (data[i].vertex == vertex) {
                if (newDist < data[i].distance) {
                    data[i].distance = newDist;
                    heapifyUp(i);
                }
                return;
            }
        }
        // If vertex not found, insert it
        insert(vertex, newDist);
    }

    bool PriorityQueue::contains(int vertex) const {
        for (int i = 0; i < size; ++i) {
            if (data[i].vertex == vertex)
                return true;
        }
        return false;
    }

    int PriorityQueue::getDistance(int vertex) const {
        for (int i = 0; i < size; ++i) {
            if (data[i].vertex == vertex)
                return data[i].distance;
        }
        throw std::runtime_error("Vertex not found in priority queue");
    }

}
