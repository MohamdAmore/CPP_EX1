// Email: mhmd2.ma71@gmail.com
#include "Queue.hpp"
#include <stdexcept>

namespace graph {

    Queue::Queue(int cap) : capacity(cap), front(0), rear(0), size(0) {
        data = new int[capacity];
    }

    Queue::~Queue() {
        delete[] data;
    }

    void Queue::enqueue(int value) {
        if (isFull()) {
            throw std::overflow_error("Queue overflow");
        }
        data[rear] = value;
        rear = (rear + 1) % capacity;
        ++size;
    }

    int Queue::dequeue() {
        if (isEmpty()) {
            throw std::underflow_error("Queue underflow");
        }
        int value = data[front];
        front = (front + 1) % capacity;
        --size;
        return value;
    }

    bool Queue::isEmpty() const {
        return size == 0;
    }

    bool Queue::isFull() const {
        return size == capacity;
    }

}
