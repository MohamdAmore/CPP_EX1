// Email: mhmd2.ma71@gmail.com
#pragma once

namespace graph {

    // Struct representing a neighbor in the adjacency list
    struct Neighbor {
        int vertex;         // ID of the neighboring vertex
        int weight;         // Edge weight
        Neighbor* next;     // Pointer to the next neighbor

        Neighbor(int v, int w, Neighbor* n = nullptr)
            : vertex(v), weight(w), next(n) {}
    };

    // Graph class implemented with adjacency list
    class Graph {
    private:
        int numVertices;        // Total number of vertices
        Neighbor** adjList;     // Array of adjacency lists (linked lists)

    public:
        // Constructor
        Graph(int vertices);

        // Destructor
        ~Graph();

        // Adds an undirected edge with optional weight (default = 1)
        void addEdge(int src, int dest, int weight = 1);

        // Removes an undirected edge; throws if it doesn't exist
        void removeEdge(int src, int dest);

        // Prints the entire graph (adjacency list)
        void print_graph() const;

        // Returns the number of vertices in the graph
        int getVertexCount() const;

        // Returns a const pointer to the adjacency list of a given vertex
        const Neighbor* getAdjList(int vertex) const;
        
        // Checks if there is an available edge 
        bool hasEdge(int u, int v) const;

    };

}
