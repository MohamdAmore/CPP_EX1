// Email: mhmd2.ma71@gmail.com
#include "graph.hpp"
#include <iostream>
#include <stdexcept>

namespace graph {

    // Constructor: initializes the graph with a fixed number of vertices
    Graph::Graph(int vertices) : numVertices(vertices) {
        adjList = new Neighbor*[numVertices];
        for (int i = 0; i < numVertices; ++i) {
            adjList[i] = nullptr;
        }
    }

    // Destructor: releases all dynamically allocated memory
    Graph::~Graph() {
        for (int i = 0; i < numVertices; ++i) {
            Neighbor* current = adjList[i];
            while (current) {
                Neighbor* toDelete = current;
                current = current->next;
                delete toDelete;
            }
        }
        delete[] adjList;
    }

    // Adds an undirected edge between two vertices with optional weight
    void Graph::addEdge(int src, int dest, int weight) {
        if (src < 0 || src >= numVertices || dest < 0 || dest >= numVertices) {
            throw std::out_of_range("Invalid vertex index");
        }

        // Add dest to src's adjacency list
        Neighbor* newNeighbor = new Neighbor(dest, weight, adjList[src]);
        adjList[src] = newNeighbor;

        // Add src to dest's adjacency list (since the graph is undirected)
        newNeighbor = new Neighbor(src, weight, adjList[dest]);
        adjList[dest] = newNeighbor;
    }

    // Removes an undirected edge between two vertices
    void Graph::removeEdge(int src, int dest) {
        if (src < 0 || src >= numVertices || dest < 0 || dest >= numVertices) {
            throw std::out_of_range("Invalid vertex index");
        }

        bool removedSrcToDest = false;
        bool removedDestToSrc = false;

        // Remove dest from src's adjacency list
        Neighbor* current = adjList[src];
        Neighbor* prev = nullptr;

        while (current) {
            if (current->vertex == dest) {
                if (prev) {
                    prev->next = current->next;
                } else {
                    adjList[src] = current->next;
                }
                delete current;
                removedSrcToDest = true;
                break;
            }
            prev = current;
            current = current->next;
        }

        // Remove src from dest's adjacency list
        current = adjList[dest];
        prev = nullptr;

        while (current) {
            if (current->vertex == src) {
                if (prev) {
                    prev->next = current->next;
                } else {
                    adjList[dest] = current->next;
                }
                delete current;
                removedDestToSrc = true;
                break;
            }
            prev = current;
            current = current->next;
        }

        if (!removedSrcToDest || !removedDestToSrc) {
            throw std::runtime_error("Edge does not exist");
        }
    }
    
    bool Graph::hasEdge(int u, int v) const {
    if (u < 0 || u >= numVertices || v < 0 || v >= numVertices) {
        return false;
    }

    Neighbor* curr = adjList[u];
    while (curr) {
        if (curr->vertex == v) {
            return true;
        }
        curr = curr->next;
    }
    return false;
}


    // Prints the adjacency list of the graph
    void Graph::print_graph() const {
        for (int i = 0; i < numVertices; ++i) {
            std::cout << "Vertex " << i << ": ";
            Neighbor* current = adjList[i];
            while (current) {
                std::cout << "(" << current->vertex << ", weight: " << current->weight << ") -> ";
                current = current->next;
            }
            std::cout << "nullptr" << std::endl;
        }
    }
    
    int Graph::getVertexCount() const {
        return numVertices;
    }
    
    const Neighbor* Graph::getAdjList(int vertex) const {
        if (vertex < 0 || vertex >= numVertices) {
            throw std::out_of_range("Invalid vertex index");
        }
        return adjList[vertex];
    }    

}
